$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("conferenceRegistration.feature");
formatter.feature({
  "line": 1,
  "name": "Conference Registration",
  "description": "",
  "id": "conference-registration",
  "keyword": "Feature"
});
formatter.before({
  "duration": 282454,
  "status": "passed"
});
formatter.before({
  "duration": 254294,
  "status": "passed"
});
formatter.scenario({
  "line": 4,
  "name": "Invalid FirstName",
  "description": "",
  "id": "conference-registration;invalid-firstname",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "User is on \u0027ConferenceRegistration\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "user enetrs invalid firstName",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "display \u0027Please fill the First Name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_is_on_ConferenceRegistration_Page()"
});
formatter.result({
  "duration": 6306207538,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_enetrs_invalid_firstName()"
});
formatter.result({
  "duration": 155969906,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.display_Please_fill_the_First_Name()"
});
formatter.result({
  "duration": 582414825,
  "status": "passed"
});
formatter.before({
  "duration": 39680,
  "status": "passed"
});
formatter.before({
  "duration": 27734,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "Invalid LastName",
  "description": "",
  "id": "conference-registration;invalid-lastname",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 10,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 12,
  "name": "User is on \u0027ConferenceRegistration\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 13,
  "name": "user enetrs invalid lastName",
  "keyword": "When "
});
formatter.step({
  "line": 14,
  "name": "display \u0027Please fill the Last Name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_is_on_ConferenceRegistration_Page()"
});
formatter.result({
  "duration": 5509854519,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_enetrs_invalid_lastName()"
});
formatter.result({
  "duration": 251554028,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.display_Please_fill_the_Last_Name()"
});
formatter.result({
  "duration": 722273778,
  "status": "passed"
});
formatter.before({
  "duration": 85333,
  "status": "passed"
});
formatter.before({
  "duration": 52054,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "Invalid Email",
  "description": "",
  "id": "conference-registration;invalid-email",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 16,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 19,
  "name": "User is on \u0027ConferenceRegistration\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "user enetrs invalid email",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "display \u0027Please fill the Email\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_is_on_ConferenceRegistration_Page()"
});
formatter.result({
  "duration": 9953171567,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_enetrs_invalid_email()"
});
formatter.result({
  "duration": 537232901,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.display_Please_fill_the_Email()"
});
formatter.result({
  "duration": 770179119,
  "status": "passed"
});
formatter.before({
  "duration": 30293,
  "status": "passed"
});
formatter.before({
  "duration": 37547,
  "status": "passed"
});
formatter.scenario({
  "line": 25,
  "name": "Invalid contact Number",
  "description": "",
  "id": "conference-registration;invalid-contact-number",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 24,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "User is on \u0027ConferenceRegistration\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "user enetrs invalid contact number",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "display \u0027Please fill valid Contact no.\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_is_on_ConferenceRegistration_Page()"
});
formatter.result({
  "duration": 8438040454,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_enetrs_invalid_contact_number()"
});
formatter.result({
  "duration": 645954533,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.display_Please_fill_valid_Contact_no()"
});
formatter.result({
  "duration": 2457413279,
  "status": "passed"
});
formatter.before({
  "duration": 50773,
  "status": "passed"
});
formatter.before({
  "duration": 43946,
  "status": "passed"
});
formatter.scenario({
  "line": 33,
  "name": "Invalid Number of People attending",
  "description": "",
  "id": "conference-registration;invalid-number-of-people-attending",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 32,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 35,
  "name": "User is on \u0027ConferenceRegistration\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 36,
  "name": "user enetrs invalid Number of People attending",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "display \u0027Number of people attending\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_is_on_ConferenceRegistration_Page()"
});
formatter.result({
  "duration": 8565333203,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_enetrs_invalid_Number_of_People_attending()"
});
formatter.result({
  "duration": 689167389,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.display_Number_of_people_attending()"
});
formatter.result({
  "duration": 1013423377,
  "status": "passed"
});
formatter.before({
  "duration": 37973,
  "status": "passed"
});
formatter.before({
  "duration": 34560,
  "status": "passed"
});
formatter.scenario({
  "line": 40,
  "name": "Invalid Building name and room no",
  "description": "",
  "id": "conference-registration;invalid-building-name-and-room-no",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 39,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 42,
  "name": "User is on \u0027ConferenceRegistration\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 43,
  "name": "user enetrs invalid Building name and room no",
  "keyword": "When "
});
formatter.step({
  "line": 44,
  "name": "display \u0027Please fill Building name and room no\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_is_on_ConferenceRegistration_Page()"
});
formatter.result({
  "duration": 9254825286,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_enetrs_invalid_Building_name_and_room_no()"
});
formatter.result({
  "duration": 831968211,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.display_Please_fill_Building_name_and_room_no()"
});
formatter.result({
  "duration": 810567437,
  "status": "passed"
});
formatter.before({
  "duration": 59306,
  "status": "passed"
});
formatter.before({
  "duration": 185173,
  "status": "passed"
});
formatter.scenario({
  "line": 47,
  "name": "Invalid Area name",
  "description": "",
  "id": "conference-registration;invalid-area-name",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 46,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 49,
  "name": "User is on \u0027ConferenceRegistration\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 50,
  "name": "user enetrs invalid Area name",
  "keyword": "When "
});
formatter.step({
  "line": 51,
  "name": "display \u0027Please fill Area name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_is_on_ConferenceRegistration_Page()"
});
formatter.result({
  "duration": 7835081175,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_enetrs_invalid_Area_name()"
});
formatter.result({
  "duration": 1113241745,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.display_Please_fill_Area_name()"
});
formatter.result({
  "duration": 625927201,
  "status": "passed"
});
formatter.before({
  "duration": 37120,
  "status": "passed"
});
formatter.before({
  "duration": 43947,
  "status": "passed"
});
formatter.scenario({
  "line": 55,
  "name": "Invalid City",
  "description": "",
  "id": "conference-registration;invalid-city",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 54,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 57,
  "name": "User is on \u0027ConferenceRegistration\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 58,
  "name": "user enetrs invalid City",
  "keyword": "When "
});
formatter.step({
  "line": 59,
  "name": "display \u0027Please fill City\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_is_on_ConferenceRegistration_Page()"
});
formatter.result({
  "duration": 5167957122,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_enetrs_invalid_City()"
});
formatter.result({
  "duration": 1180276711,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.display_Please_fill_City()"
});
formatter.result({
  "duration": 2674427743,
  "status": "passed"
});
formatter.before({
  "duration": 129706,
  "status": "passed"
});
formatter.before({
  "duration": 105813,
  "status": "passed"
});
formatter.scenario({
  "line": 62,
  "name": "Invalid State",
  "description": "",
  "id": "conference-registration;invalid-state",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 61,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 64,
  "name": "User is on \u0027ConferenceRegistration\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 65,
  "name": "user enetrs invalid State",
  "keyword": "When "
});
formatter.step({
  "line": 66,
  "name": "display \u0027Please fill the State\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_is_on_ConferenceRegistration_Page()"
});
formatter.result({
  "duration": 4305081991,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_enetrs_invalid_State()"
});
formatter.result({
  "duration": 1246358075,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.display_Please_fill_the_State()"
});
formatter.result({
  "duration": 709355148,
  "status": "passed"
});
formatter.before({
  "duration": 55467,
  "status": "passed"
});
formatter.before({
  "duration": 41387,
  "status": "passed"
});
formatter.scenario({
  "line": 69,
  "name": "Invalid Member Status",
  "description": "",
  "id": "conference-registration;invalid-member-status",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 68,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 71,
  "name": "User is on \u0027ConferenceRegistration\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 72,
  "name": "user enetrs invalid Member Status",
  "keyword": "When "
});
formatter.step({
  "line": 73,
  "name": "display \u0027Please fill the Member Status\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_is_on_ConferenceRegistration_Page()"
});
formatter.result({
  "duration": 10944549049,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_enetrs_invalid_Member_Status()"
});
formatter.result({
  "duration": 1626462242,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.display_Please_fill_the_Member_Status()"
});
formatter.result({
  "duration": 1011986362,
  "status": "passed"
});
formatter.before({
  "duration": 30294,
  "status": "passed"
});
formatter.before({
  "duration": 24747,
  "status": "passed"
});
formatter.scenario({
  "line": 76,
  "name": "Valid Details",
  "description": "",
  "id": "conference-registration;valid-details",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 75,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 78,
  "name": "User is on \u0027ConferenceRegistration\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 79,
  "name": "user enters valid details",
  "keyword": "When "
});
formatter.step({
  "line": 80,
  "name": "display \u0027Personal details are validated\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_is_on_ConferenceRegistration_Page()"
});
formatter.result({
  "duration": 9349003966,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_enters_valid_details()"
});
formatter.result({
  "duration": 2101530156,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.display_Personal_details_are_validated()"
});
formatter.result({
  "duration": 775840566,
  "status": "passed"
});
formatter.before({
  "duration": 67413,
  "status": "passed"
});
formatter.before({
  "duration": 37120,
  "status": "passed"
});
formatter.scenario({
  "line": 83,
  "name": "Page loads",
  "description": "",
  "id": "conference-registration;page-loads",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 82,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 85,
  "name": "User is on \u0027ConferenceRegistration\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 86,
  "name": "user enetrs url",
  "keyword": "When "
});
formatter.step({
  "line": 87,
  "name": "page should be loaded",
  "keyword": "Then "
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_is_on_ConferenceRegistration_Page()"
});
formatter.result({
  "duration": 8592652278,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.user_enetrs_url()"
});
formatter.result({
  "duration": 29440,
  "status": "passed"
});
formatter.match({
  "location": "ConferenceRegistrationStepDefination.page_should_be_loaded()"
});
formatter.result({
  "duration": 739890867,
  "status": "passed"
});
formatter.uri("paymentDetails.feature");
formatter.feature({
  "line": 1,
  "name": "Payment Details",
  "description": "",
  "id": "payment-details",
  "keyword": "Feature"
});
formatter.before({
  "duration": 30293,
  "status": "passed"
});
formatter.before({
  "duration": 26027,
  "status": "passed"
});
formatter.scenario({
  "line": 4,
  "name": "Valid Title",
  "description": "",
  "id": "payment-details;valid-title",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "user is on Payment Details page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "user enters loads the page",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "valid page should open",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefination.user_is_on_Payment_Details_page()"
});
formatter.result({
  "duration": 4566567979,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefination.user_enters_loads_the_page()"
});
formatter.result({
  "duration": 29867,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefination.valid_page_should_open()"
});
formatter.result({
  "duration": 643241783,
  "status": "passed"
});
formatter.before({
  "duration": 67413,
  "status": "passed"
});
formatter.before({
  "duration": 64000,
  "status": "passed"
});
formatter.scenario({
  "line": 11,
  "name": "Invalid cardHolder name",
  "description": "",
  "id": "payment-details;invalid-cardholder-name",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 10,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 13,
  "name": "user is on Payment Details page",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "user enters invalid name",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "displays \u0027Please fill name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefination.user_is_on_Payment_Details_page()"
});
formatter.result({
  "duration": 3097530578,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefination.user_enters_invalid_name()"
});
formatter.result({
  "duration": 168111575,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefination.displays_Please_fill_name()"
});
formatter.result({
  "duration": 594915321,
  "status": "passed"
});
formatter.before({
  "duration": 36694,
  "status": "passed"
});
formatter.before({
  "duration": 29867,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Invalid Debit Card Number",
  "description": "",
  "id": "payment-details;invalid-debit-card-number",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 17,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 20,
  "name": "user is on Payment Details page",
  "keyword": "Given "
});
formatter.step({
  "line": 21,
  "name": "user enters invalid Debit Card Number",
  "keyword": "When "
});
formatter.step({
  "line": 22,
  "name": "displays \u0027Please fill Debit Card Number\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefination.user_is_on_Payment_Details_page()"
});
formatter.result({
  "duration": 3882078142,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefination.user_enters_invalid_Debit_Card_Number()"
});
formatter.result({
  "duration": 203399514,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefination.displays_Please_fill_Debit_Card_Number()"
});
formatter.result({
  "duration": 894857679,
  "status": "passed"
});
formatter.before({
  "duration": 1317975,
  "status": "passed"
});
formatter.before({
  "duration": 994561,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Invalid expiration month",
  "description": "",
  "id": "payment-details;invalid-expiration-month",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 25,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 28,
  "name": "user is on Payment Details page",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "user enters invalid expiration month",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "displays \u0027Please fill expiration month\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefination.user_is_on_Payment_Details_page()"
});
formatter.result({
  "duration": 4420066671,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefination.user_enters_invalid_expiration_month()"
});
formatter.result({
  "duration": 487485211,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefination.displays_Please_fill_expiration_month()"
});
formatter.result({
  "duration": 498282877,
  "status": "passed"
});
formatter.before({
  "duration": 211627,
  "status": "passed"
});
formatter.before({
  "duration": 57173,
  "status": "passed"
});
formatter.scenario({
  "line": 33,
  "name": "Invalid expiration year",
  "description": "",
  "id": "payment-details;invalid-expiration-year",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 32,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 35,
  "name": "user is on Payment Details page",
  "keyword": "Given "
});
formatter.step({
  "line": 36,
  "name": "user enters invalid expiration year",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "displays \u0027Please fill expiration year\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefination.user_is_on_Payment_Details_page()"
});
formatter.result({
  "duration": 4571750278,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefination.user_enters_invalid_expiration_year()"
});
formatter.result({
  "duration": 526666060,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefination.displays_Please_fill_expiration_year()"
});
formatter.result({
  "duration": 574182281,
  "status": "passed"
});
formatter.before({
  "duration": 34133,
  "status": "passed"
});
formatter.before({
  "duration": 25600,
  "status": "passed"
});
formatter.scenario({
  "line": 40,
  "name": "Valid details",
  "description": "",
  "id": "payment-details;valid-details",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 39,
      "name": "@execute"
    }
  ]
});
formatter.step({
  "line": 42,
  "name": "user is on Payment Details page",
  "keyword": "Given "
});
formatter.step({
  "line": 43,
  "name": "user enters valid  payment details",
  "keyword": "When "
});
formatter.step({
  "line": 44,
  "name": "displays \u0027Conference Room Booking successfully done!!!\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PaymentDetailsStepDefination.user_is_on_Payment_Details_page()"
});
formatter.result({
  "duration": 5164282237,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefination.user_enters_valid_payment_details()"
});
formatter.result({
  "duration": 679220069,
  "status": "passed"
});
formatter.match({
  "location": "PaymentDetailsStepDefination.displays_Conference_Room_Booking_successfully_done()"
});
formatter.result({
  "duration": 804125616,
  "status": "passed"
});
});